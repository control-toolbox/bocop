mkdir -p build
cd build
cmake -DAPP_DIR=${PWD}/.. ../../core
make -j
cd ..
