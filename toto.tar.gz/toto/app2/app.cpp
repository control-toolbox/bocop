#include <iostream>

void callsign()
{
  std::cout << "I am app2" << std::endl;
}
