#include <iostream>
#include <core.h>

int main()
{
  location();
  callsign();
  return 0;
}
