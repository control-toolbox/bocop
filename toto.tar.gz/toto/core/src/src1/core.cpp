#include <iostream>
#include <string>
#include <unistd.h>

void location()
{
  char tmp[256];
  getcwd(tmp, 256);
  std::cout << tmp << std::endl;
}
