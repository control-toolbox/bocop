#include <iostream>

void callsign()
{
  std::cout << "I am app1" << std::endl;
}
